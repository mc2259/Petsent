//
//  ViewController3.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 02/03/20.

import UIKit

class ViewController3: UIViewController {

    var tableView: UITableView!

    let reuseIdentifier = "cafeteriaCellReuse"
    let cellHeight: CGFloat = 150
    var cafeterias: [Cafeteria]!

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Top Donors For Jamie"
        view.backgroundColor = .white
        
        let appel = Cafeteria(name: "Rakshit", isFavorite: false, rating: .moderate,imagestring:"image1",money:"Money Donated: $ 10000",place:"Place: Global")
        let rpcc = Cafeteria(name: "Maitreyi", isFavorite: false, rating: .moderate,imagestring:"image5",money:"Money Donated: $ 5000",place:"Place: Ithaca")
        let becker = Cafeteria(name: "Tarannum", isFavorite: false, rating: .good,imagestring:"image3",money: "Money Donated: $200",place:"Place: Global")
        let cook = Cafeteria(name: "Abhishek", isFavorite: false, rating: .great,imagestring:"image4",money:"Money Donated: $ 100",place:"Place: Kansas")
        let bis = Cafeteria(name: "Hope", isFavorite: false, rating: .great,imagestring:"unnamed",money:"Money Donated: $ 50",place:"Place: Montana")
        cafeterias = [appel, rpcc, becker, cook,bis]

        // Initialize tableView
        tableView = UITableView()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(CafeteriaTableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        view.addSubview(tableView)

        setupConstraints()
    }

    func setupConstraints() {
        // Setup the constraints for our views
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }


}

/// UITableViewDataSource
/// - Tell the table view how many rows should be in each section
/// - Tell the table view what cell to display for each row
extension ViewController3: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cafeterias.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! CafeteriaTableViewCell
        let cafeteria = cafeterias[indexPath.row]
        cell.configure(for: cafeteria)
        cell.selectionStyle = .none
        return cell
    }
}

/// UITableViewDelegate
/// - Tell the table view what height to use for each row
/// - Tell the table view what should happen if we select a row
/// - Tell the table view what should happen if we deselect a row
extension ViewController3: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cafeteria = cafeterias[indexPath.row]
        let cell = tableView.cellForRow(at: indexPath) as! CafeteriaTableViewCell
        cafeteria.isFavorite.toggle()
        cell.toggleHeart(for: cafeteria.isFavorite)
        
        
    }
}
