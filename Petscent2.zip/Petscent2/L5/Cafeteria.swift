//
//  Cafeteria.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 02/03/20.
//  Copyright © 2020 Kevin Chan. All rights reserved.
//

//
//  File.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 02/03/20.


import Foundation

enum CafeteriaRating {
    case terrible
    case bad
    case moderate
    case good
    case great
}

class Cafeteria {
    var name: String
    var isFavorite: Bool
    var rating: CafeteriaRating
    var imagestring:String
    var money:String
    var place:String
    
    init(name: String, isFavorite: Bool, rating: CafeteriaRating,imagestring:String,money:String,place:String) {
        self.name = name
        self.isFavorite = isFavorite
        self.rating = rating
        self.imagestring=imagestring
        self.money=money
        self.place=place
    }
    
    func getRatingString() -> String {
        switch rating {
        case .terrible:
            return "Terrible"
        case .bad:
            return "Bad"
        case .moderate:
            return "Moderate"
        case .good:
            return "Good"
        case .great:
            return "Great"
        }
    }
}

