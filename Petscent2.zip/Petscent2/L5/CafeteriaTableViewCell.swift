//
//  CafeteriaTableViewCell.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 02/03/20.
//  Copyright © 2020 Kevin Chan. All rights reserved.
//
import UIKit

class CafeteriaTableViewCell: UITableViewCell {
    
    var nameLabel: UILabel!
    var ratingLabel: UILabel!
    var heartImageView: UIImageView!
    var imageview:UIImageView!
    
    var number:CGFloat=1
    
    let padding: CGFloat = 8
    let labelHeight: CGFloat = 16
    let heartImageLength: CGFloat = 20
    var moneyLabel:UILabel!
    var placeLabel:UILabel!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        nameLabel = UILabel()
        nameLabel.font = UIFont.systemFont(ofSize: 14)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nameLabel)
        
        ratingLabel = UILabel()
        ratingLabel.font = UIFont.systemFont(ofSize: 12)
        ratingLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(ratingLabel)
        
        moneyLabel = UILabel()
        moneyLabel.font = UIFont.systemFont(ofSize: 12)
        moneyLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(moneyLabel)
        
        placeLabel = UILabel()
        placeLabel.font = UIFont.systemFont(ofSize: 12)
        placeLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(placeLabel)
        
        heartImageView = UIImageView(image: UIImage(named: "heart"))
        heartImageView.contentMode = .scaleAspectFit
        heartImageView.isHidden = true
        heartImageView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(heartImageView)
        
        imageview = UIImageView()
        imageview.contentMode = .scaleAspectFit
        //imageview.layer.cornerRadius=20
        imageview.translatesAutoresizingMaskIntoConstraints = false
               contentView.addSubview(imageview)
        
        
        
        setupConstraints()
        
    }
    
    func setupConstraints() {
        
        
        NSLayoutConstraint.activate([
            ratingLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            ratingLabel.heightAnchor.constraint(equalToConstant: labelHeight),
            ratingLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor)
        ])
        
        NSLayoutConstraint.activate([
                 moneyLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
                 moneyLabel.heightAnchor.constraint(equalToConstant: labelHeight),
                 moneyLabel.topAnchor.constraint(equalTo: ratingLabel.bottomAnchor)
             ])
             
        
        NSLayoutConstraint.activate([
                 placeLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
                 placeLabel.heightAnchor.constraint(equalToConstant: labelHeight),
                 placeLabel.topAnchor.constraint(equalTo: moneyLabel.bottomAnchor)
             ])
             
        
        NSLayoutConstraint.activate([
            heartImageView.widthAnchor.constraint(equalToConstant: heartImageLength),
            heartImageView.heightAnchor.constraint(equalToConstant: heartImageLength),
            heartImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
            heartImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
        NSLayoutConstraint.activate([
            imageview.widthAnchor.constraint(equalToConstant: 5*heartImageLength),
            imageview.heightAnchor.constraint(equalToConstant: 5*heartImageLength),
            imageview.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            imageview.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
        NSLayoutConstraint.activate([
            nameLabel.leadingAnchor.constraint(equalTo: imageview.trailingAnchor, constant: padding+30),
            nameLabel.heightAnchor.constraint(equalToConstant: labelHeight),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: padding+20)
        ])
        
        
        
        
    }
    
    func configure(for cafeteria: Cafeteria) {
        nameLabel.text = cafeteria.name
        ratingLabel.text = "Rating: \(cafeteria.getRatingString())"
        imageview.image=UIImage(named:cafeteria.imagestring)
        moneyLabel.text=cafeteria.money
        placeLabel.text=cafeteria.place
        
       
        
    }
    
    func toggleHeart(for isFavorite: Bool) {
        heartImageView.isHidden = !isFavorite
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

