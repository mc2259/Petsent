//
//  ViewControllerPet.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 02/03/20.
//  Copyright © 2020 Kevin Chan. All rights reserved.
//

//
//

import UIKit

class ViewControllerPet: UIViewController {
    
    var imageView: UIImageView!
    var nameLabel: UILabel!
    var name2Label: UILabel!
    var name3Label: UILabel!
    var vetHospitalLabel: UILabel!
    var vetcontact: UILabel!
    var somethinginfo:UILabel!
    var followButton: UIButton!
    var bioTextView: UITextView!
    var bioTextView1: UITextView!
    var bioTextView2: UITextView!
    var bioTextView3: UITextView!
    //Nmae of Vet Hosp
    
    var isFollowing: Bool = false
    
    let imageViewLength: CGFloat = 300

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        
        imageView = UIImageView()
        imageView.image = UIImage(named: "unnamed")
        imageView.clipsToBounds = true
        //imageView.layer.cornerRadius = imageViewLength / 2
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        nameLabel = UILabel()
        nameLabel.text = "Profile Information"
        nameLabel.textColor = .black
        nameLabel.textAlignment = .center
        nameLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameLabel)
        
        name2Label = UILabel()
               name2Label.text = "Name of Vet Hospital:"
               name2Label.textColor = .black
               name2Label.textAlignment = .center
               name2Label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
               name2Label.translatesAutoresizingMaskIntoConstraints = false
               view.addSubview(name2Label)
        
        name3Label = UILabel()
        name3Label.text = "Bill Info:"
        name3Label.textColor = .black
        name3Label.textAlignment = .center
        name3Label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        name3Label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(name3Label)
        
        vetHospitalLabel = UILabel()
        vetHospitalLabel.text = "Location:"
        vetHospitalLabel.textColor = .black
        vetHospitalLabel.textAlignment = .center
        vetHospitalLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        vetHospitalLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(vetHospitalLabel)
        
        somethinginfo = UILabel()
               somethinginfo.text = "Problem Description:"
               somethinginfo.textColor = .black
               somethinginfo.textAlignment = .center
               somethinginfo.font = UIFont.systemFont(ofSize: 16, weight: .bold)
               somethinginfo.translatesAutoresizingMaskIntoConstraints = false
               view.addSubview(somethinginfo)
        
        vetcontact = UILabel()
        vetcontact.text = "Amount"
        vetcontact.textColor = .black
        vetcontact.textAlignment = .center
        vetcontact.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        vetcontact.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(vetcontact)
        
        followButton = UIButton()
        followButton.backgroundColor = .systemBlue
        followButton.addTarget(self, action: #selector(followButtonPressed), for: .touchUpInside)
        followButton.setTitle("Upload Bill Scan", for: .normal)
        followButton.setTitleColor(.white, for: .normal)
        followButton.layer.borderColor = UIColor.systemBlue.cgColor
        followButton.layer.borderWidth = 1
        followButton.translatesAutoresizingMaskIntoConstraints = false
        followButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        view.addSubview(followButton)
        
        bioTextView = UITextView()
        
        bioTextView.textColor = .black
        bioTextView.isEditable = true
        bioTextView.layer.borderColor = UIColor.systemGray.cgColor
        bioTextView.layer.borderWidth = 1
        bioTextView.layer.cornerRadius=20
        bioTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bioTextView)
        
        
        
        bioTextView1 = UITextView()
       
        bioTextView1.textColor = .black
        bioTextView1.isEditable = true
        bioTextView1.layer.borderColor = UIColor.systemGray.cgColor
        bioTextView1.layer.borderWidth = 1
        bioTextView1.translatesAutoresizingMaskIntoConstraints = false
        bioTextView1.layer.cornerRadius=20
        view.addSubview(bioTextView1)
        
        
        bioTextView2 = UITextView()
        
        bioTextView2.textColor = .black
        bioTextView2.isEditable = true
        bioTextView2.layer.borderColor = UIColor.systemGray.cgColor
        bioTextView2.layer.borderWidth = 1
        bioTextView2.translatesAutoresizingMaskIntoConstraints = false
        bioTextView2.layer.cornerRadius=20
        view.addSubview(bioTextView2)
        
        bioTextView3 = UITextView()
             
             bioTextView3.textColor = .black
             bioTextView3.isEditable = true
             bioTextView3.layer.borderColor = UIColor.systemGray.cgColor
             bioTextView3.layer.borderWidth = 1
             bioTextView3.translatesAutoresizingMaskIntoConstraints = false
        bioTextView3.layer.cornerRadius=20
             view.addSubview(bioTextView3)


        
        setupConstraints()
    }
    
    @objc func followButtonPressed() {
        followButton.setTitle(isFollowing ? "Follow" : "Following", for: .normal)
        followButton.setTitleColor(isFollowing ? .systemBlue : .white, for: .normal)
        followButton.backgroundColor = isFollowing ? .white : .systemBlue
        isFollowing.toggle()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalToConstant: imageViewLength),
            imageView.heightAnchor.constraint(equalToConstant: imageViewLength),
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
        ])
        NSLayoutConstraint.activate([
            name3Label.topAnchor.constraint(equalTo:nameLabel.bottomAnchor,constant: 15),
            name3Label.bottomAnchor.constraint(equalTo:name3Label.topAnchor,constant: 15),
            name3Label.leadingAnchor.constraint(equalTo:view.leadingAnchor,constant: 15)
        ])
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 15),
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
        
        
        
        NSLayoutConstraint.activate([
            name2Label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            
            name2Label.topAnchor.constraint(equalTo: followButton.bottomAnchor, constant: 15),
            name2Label.bottomAnchor.constraint(equalTo: name2Label.topAnchor,constant: 50),
        ])
        
        NSLayoutConstraint.activate([
            vetHospitalLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            
            vetHospitalLabel.topAnchor.constraint(equalTo: name2Label.bottomAnchor, constant: 15),
            vetHospitalLabel.bottomAnchor.constraint(equalTo: vetHospitalLabel.topAnchor,constant: 50),
        ])
        NSLayoutConstraint.activate([
            somethinginfo.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            
            somethinginfo.topAnchor.constraint(equalTo: vetHospitalLabel.bottomAnchor, constant: 15),
            somethinginfo.bottomAnchor.constraint(equalTo: somethinginfo.topAnchor,constant: 50),
        ])
        
        NSLayoutConstraint.activate([
            vetcontact.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            
            vetcontact.topAnchor.constraint(equalTo: bioTextView2.bottomAnchor, constant: 15),
            vetcontact.bottomAnchor.constraint(equalTo: vetcontact.topAnchor,constant: 50),
        ])
        
        
        
        NSLayoutConstraint.activate([
            bioTextView.leadingAnchor.constraint(equalTo: name2Label.trailingAnchor, constant: 15),
            bioTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            bioTextView.topAnchor.constraint(equalTo: followButton.bottomAnchor, constant: 15),
            bioTextView.bottomAnchor.constraint(equalTo: bioTextView.topAnchor,constant: 50),
        ])
        
        NSLayoutConstraint.activate([
            followButton.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            followButton.leadingAnchor.constraint(equalTo:bioTextView.leadingAnchor)
            
        ])
        NSLayoutConstraint.activate([
            bioTextView1.leadingAnchor.constraint(equalTo: bioTextView.leadingAnchor),
            bioTextView1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            bioTextView1.topAnchor.constraint(equalTo: vetHospitalLabel.topAnchor),
            bioTextView1.bottomAnchor.constraint(equalTo: vetHospitalLabel.bottomAnchor),
        ])
        
        NSLayoutConstraint.activate([
            bioTextView2.leadingAnchor.constraint(equalTo: somethinginfo.trailingAnchor, constant: 15),
            bioTextView2.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            bioTextView2.topAnchor.constraint(equalTo: somethinginfo.topAnchor),
            bioTextView2.bottomAnchor.constraint(equalTo: bioTextView2.topAnchor,constant: 80),
        ])
        
        NSLayoutConstraint.activate([
                   bioTextView3.leadingAnchor.constraint(equalTo: somethinginfo.trailingAnchor, constant: 15),
                   bioTextView3.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
                   bioTextView3.topAnchor.constraint(equalTo: vetcontact.topAnchor),
                   bioTextView3.bottomAnchor.constraint(equalTo: bioTextView3.topAnchor,constant: 80),
               ])
    }

}
